export default function QuizPage() {
  return (
    <div>
      webp 형식
      <img src="https://velog.velcdn.com/images/dooin/post/a836cacf-7446-41ae-92b4-c47aa772d89a/image.webp"></img>
    </div>
  );
}
